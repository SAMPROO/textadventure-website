

def passage(conn, location_id, item):
